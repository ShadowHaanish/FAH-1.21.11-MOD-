package com.visualmodules.mixin;

import com.visualmodules.module.FreeLookModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void vm$freeLookInput(double dx, double dy, CallbackInfo ci) {
        if (FreeLookModule.active && (Object) this == MinecraftClient.getInstance().player) {
            FreeLookModule.rotate(dx, dy);
            ci.cancel();
        }
    }
}
