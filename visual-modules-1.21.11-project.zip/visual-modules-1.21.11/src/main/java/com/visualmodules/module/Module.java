package com.visualmodules.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    public final String name;
    public final String description;
    private boolean enabled;

    protected Module(String name, String description) {
        this.name = name;
        this.description = description;
    }

    protected static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    /** Right-click in the GUI: cycle an option. */
    public void onRightClick() {}
    /** Small status text shown next to the description. */
    public String status() { return null; }
}
