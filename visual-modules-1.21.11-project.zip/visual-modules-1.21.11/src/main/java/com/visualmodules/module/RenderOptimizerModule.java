package com.visualmodules.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;

/** Applies a lightweight graphics preset and restores your settings when turned off. */
public class RenderOptimizerModule extends Module {
    public static final RenderOptimizerModule INSTANCE = new RenderOptimizerModule();

    private ParticlesMode oldParticles;
    private GraphicsMode oldGraphics;
    private CloudRenderMode oldClouds;
    private double oldEntityScale;

    private RenderOptimizerModule() { super("Render Optimizer", "Lowers graphics load for more FPS"); }

    @Override public void onEnable() {
        MinecraftClient mc = mc();
        GameOptions o = mc.options;
        oldParticles = o.getParticles().getValue();
        oldGraphics = o.getGraphicsMode().getValue();
        oldClouds = o.getCloudRenderMode().getValue();
        oldEntityScale = o.getEntityDistanceScaling().getValue();

        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getEntityDistanceScaling().setValue(0.5);
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    @Override public void onDisable() {
        MinecraftClient mc = mc();
        GameOptions o = mc.options;
        if (oldParticles == null) return;
        o.getParticles().setValue(oldParticles);
        o.getGraphicsMode().setValue(oldGraphics);
        o.getCloudRenderMode().setValue(oldClouds);
        o.getEntityDistanceScaling().setValue(oldEntityScale);
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }
}
