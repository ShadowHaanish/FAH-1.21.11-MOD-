package com.visualmodules.module;

import net.minecraft.client.world.ClientWorld;

public class AmbienceModule extends Module {
    public static final AmbienceModule INSTANCE = new AmbienceModule();
    private static final String[] NAMES = {"Day", "Sunset", "Night", "Midnight"};
    private static final long[] TIMES = {1000, 12500, 14000, 18000};
    private int mode = 3;

    private AmbienceModule() { super("Ambience", "Changes the ambience of the game"); }

    @Override public void onTick() {
        ClientWorld w = mc().world;
        if (w == null) return;
        w.getLevelProperties().setTimeOfDay(TIMES[mode]);
        w.setRainGradient(0f);
        w.setThunderGradient(0f);
    }

    @Override public void onRightClick() { mode = (mode + 1) % NAMES.length; }
    @Override public String status() { return NAMES[mode]; }
}
