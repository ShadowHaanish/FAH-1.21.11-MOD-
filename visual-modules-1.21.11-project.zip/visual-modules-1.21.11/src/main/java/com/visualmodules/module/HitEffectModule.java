package com.visualmodules.module;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.ActionResult;

public class HitEffectModule extends Module {
    public static final HitEffectModule INSTANCE = new HitEffectModule();
    private static final ParticleEffect[] EFFECTS = {
            ParticleTypes.CRIT, ParticleTypes.ENCHANTED_HIT, ParticleTypes.HEART, ParticleTypes.FLAME};
    private static final String[] NAMES = {"Crit", "Enchant", "Hearts", "Flame"};
    private int mode = 0;

    private HitEffectModule() { super("Hit Effect", "Spawns particles when you hit an entity"); }

    public void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (isEnabled() && world instanceof ClientWorld && entity instanceof LivingEntity) {
                for (int i = 0; i < 10; i++) {
                    mc().particleManager.addParticle(EFFECTS[mode],
                            entity.getX() + (Math.random() - 0.5) * entity.getWidth(),
                            entity.getY() + Math.random() * entity.getHeight(),
                            entity.getZ() + (Math.random() - 0.5) * entity.getWidth(),
                            0, 0.1, 0);
                }
            }
            return ActionResult.PASS;
        });
    }

    @Override public void onRightClick() { mode = (mode + 1) % EFFECTS.length; }
    @Override public String status() { return NAMES[mode]; }
}
