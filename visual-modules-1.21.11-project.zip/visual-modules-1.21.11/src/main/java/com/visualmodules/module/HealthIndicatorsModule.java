package com.visualmodules.module;

public class HealthIndicatorsModule extends Module {
    public static final HealthIndicatorsModule INSTANCE = new HealthIndicatorsModule();
    private HealthIndicatorsModule() { super("Health Indicators", "Shows health on players"); }
}
