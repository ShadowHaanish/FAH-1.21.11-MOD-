package com.visualmodules.mixin;

import com.visualmodules.module.HealthIndicatorsModule;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public abstract class EntityRendererMixin {
    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void vm$health(Entity entity, EntityRenderState state, float tickProgress, CallbackInfo ci) {
        if (!HealthIndicatorsModule.INSTANCE.isEnabled()
                || !(entity instanceof PlayerEntity)
                || state.displayName == null) return;

        LivingEntity living = (LivingEntity) entity;
        float hp = living.getHealth() + living.getAbsorptionAmount();
        Formatting color = hp >= 15 ? Formatting.GREEN : hp >= 8 ? Formatting.YELLOW : Formatting.RED;
        state.displayName = state.displayName.copy().append(
                Text.literal(String.format(" \u2665 %.1f", hp)).formatted(color));
    }
}
