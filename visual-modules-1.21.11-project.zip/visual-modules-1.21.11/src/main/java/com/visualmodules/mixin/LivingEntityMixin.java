package com.visualmodules.mixin;

import com.visualmodules.module.AnimationsModule;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void vm$smoothSwing(CallbackInfoReturnable<Integer> cir) {
        if (AnimationsModule.INSTANCE.isEnabled() && (Object) this instanceof ClientPlayerEntity) {
            cir.setReturnValue(Math.max(cir.getReturnValue(), AnimationsModule.INSTANCE.swingDuration()));
        }
    }
}
