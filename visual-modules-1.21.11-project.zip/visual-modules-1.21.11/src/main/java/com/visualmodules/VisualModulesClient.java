package com.visualmodules;

import com.visualmodules.gui.ClickGuiScreen;
import com.visualmodules.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class VisualModulesClient implements ClientModInitializer {
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("visualmodules", "main"));
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.visualmodules.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) client.setScreen(new ClickGuiScreen());
            ModuleManager.tick();
        });
    }
}
