package com.visualmodules.gui;

import com.visualmodules.module.Module;
import com.visualmodules.module.ModuleManager;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 340, ROW_H = 32, GAP = 6, HEADER = 52;

    public ClickGuiScreen() { super(Text.literal("Visual Modules")); }

    private int panelX() { return (width - PANEL_W) / 2; }
    private int panelH() { return HEADER + ModuleManager.MODULES.size() * (ROW_H + GAP) + 22; }
    private int panelY() { return Math.max(4, (height - panelH()) / 2); }
    private int rowY(int i) { return panelY() + HEADER + i * (ROW_H + GAP); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        int x = panelX(), y = panelY();
        ctx.fill(x, y, x + PANEL_W, y + panelH(), 0xF0120D1A);

        ctx.drawText(textRenderer, Text.literal("Visual ").formatted(Formatting.ITALIC, Formatting.LIGHT_PURPLE)
                .append(Text.literal("Modules").formatted(Formatting.WHITE, Formatting.BOLD)), x + 14, y + 12, 0xFFFFFFFF, false);
        ctx.drawText(textRenderer, ModuleManager.MODULES.size() + " modules \u00b7 " + ModuleManager.enabledCount() + " enabled",
                x + 14, y + 28, 0xFF8A8296, false);

        for (int i = 0; i < ModuleManager.MODULES.size(); i++) {
            Module m = ModuleManager.MODULES.get(i);
            int ry = rowY(i);
            boolean hover = mx >= x + 10 && mx <= x + PANEL_W - 10 && my >= ry && my <= ry + ROW_H;
            ctx.fill(x + 10, ry, x + PANEL_W - 10, ry + ROW_H, hover ? 0xFF241B33 : 0xFF1A1424);
            if (m.isEnabled()) ctx.fill(x + 10, ry, x + 12, ry + ROW_H, 0xFF9B59B6);

            ctx.drawText(textRenderer, m.name, x + 20, ry + 7, 0xFFF0ECF5, false);
            String desc = m.description + (m.status() != null ? "  \u00b7  " + m.status() : "");
            ctx.drawText(textRenderer, desc, x + 20, ry + 19, 0xFF7A7388, false);

            // toggle pill
            int tx = x + PANEL_W - 52, ty = ry + 9;
            ctx.fill(tx, ty, tx + 28, ty + 14, m.isEnabled() ? 0xFF9B59B6 : 0xFF2A2236);
            int kx = m.isEnabled() ? tx + 16 : tx + 2;
            ctx.fill(kx, ty + 2, kx + 10, ty + 12, 0xFFFFFFFF);
        }
        ctx.drawText(textRenderer, "Left-click: toggle  \u00b7  Right-click: change option",
                x + 14, y + panelH() - 16, 0xFF6A6378, false);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();
        int x = panelX();
        for (int i = 0; i < ModuleManager.MODULES.size(); i++) {
            int ry = rowY(i);
            if (mx >= x + 10 && mx <= x + PANEL_W - 10 && my >= ry && my <= ry + ROW_H) {
                Module m = ModuleManager.MODULES.get(i);
                if (button == 0) m.toggle();
                else if (button == 1) m.onRightClick();
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }
}
