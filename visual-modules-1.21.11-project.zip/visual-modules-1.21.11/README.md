# Visual Modules (Fabric, Minecraft 1.21.11)

Modules: Ambience, Animations, Free Look, Health Indicators, Hit Effect, Render Optimizer.

## Build
Requires JDK 21 and Gradle 8.8+ (or run `gradle wrapper` once, then use ./gradlew).

    gradle build

Your jar: build/libs/visual-modules-1.0.0.jar

## Install
1. Install Fabric Loader for 1.21.11 (fabricmc.net/use) and Fabric API.
2. Drop visual-modules-1.0.0.jar into .minecraft/mods
3. In game: RIGHT SHIFT opens the module menu. Left-click toggles, right-click cycles options.
   Free Look: hold LEFT ALT.
