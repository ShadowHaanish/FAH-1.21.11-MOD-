package com.visualmodules.module;

public class AnimationsModule extends Module {
    public static final AnimationsModule INSTANCE = new AnimationsModule();
    private static final int[] DURATIONS = {10, 14, 18};
    private static final String[] NAMES = {"Smooth", "Slower", "Slowest"};
    private int mode = 0;

    private AnimationsModule() { super("Animations", "Renders custom smooth swing animations"); }

    public int swingDuration() { return DURATIONS[mode]; }

    @Override public void onRightClick() { mode = (mode + 1) % DURATIONS.length; }
    @Override public String status() { return NAMES[mode]; }
}
