package com.visualmodules.module;

import java.util.List;

public class ModuleManager {
    public static final List<Module> MODULES = List.of(
            AmbienceModule.INSTANCE,
            AnimationsModule.INSTANCE,
            FreeLookModule.INSTANCE,
            HealthIndicatorsModule.INSTANCE,
            HitEffectModule.INSTANCE,
            RenderOptimizerModule.INSTANCE
    );

    public static void init() {
        HitEffectModule.INSTANCE.register();
    }

    public static void tick() {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick();
    }

    public static long enabledCount() {
        return MODULES.stream().filter(Module::isEnabled).count();
    }
}
