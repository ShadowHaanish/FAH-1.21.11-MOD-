package com.visualmodules.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Hold LEFT ALT to look around without turning your player. */
public class FreeLookModule extends Module {
    public static final FreeLookModule INSTANCE = new FreeLookModule();

    public static boolean active = false;
    public static float yaw, pitch;
    private Perspective previous = Perspective.FIRST_PERSON;

    private FreeLookModule() { super("Free Look", "Allows you to look around without rotating"); }

    public static void rotate(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }

    @Override public void onTick() {
        MinecraftClient mc = mc();
        if (mc.player == null) { active = false; return; }
        boolean held = mc.currentScreen == null && GLFW.glfwGetKey(
                mc.getWindow().getHandle(), GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS;
        if (held && !active) {
            active = true;
            yaw = mc.player.getYaw();
            pitch = mc.player.getPitch();
            previous = mc.options.getPerspective();
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!held && active) {
            stop();
        }
    }

    private void stop() {
        active = false;
        mc().options.setPerspective(previous);
    }

    @Override public void onDisable() { if (active) stop(); }
    @Override public String status() { return "Hold L-Alt"; }
}
